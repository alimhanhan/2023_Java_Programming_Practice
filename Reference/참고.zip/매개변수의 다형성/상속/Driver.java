package sec02.exam04;

public class Driver {
	public void drive(Vehicle vehicle) {
		vehicle.run();
	}
}
