
public interface Vehicle {
	public void run();
}
